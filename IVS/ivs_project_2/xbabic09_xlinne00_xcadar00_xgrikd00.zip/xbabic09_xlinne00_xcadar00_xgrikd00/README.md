# CalcTS

Calculator project for IVS FIT VUT

## Getting Started

For product installation, there is automatized installer included.

### Prerequisites

Installer will take care of all needed software, including .NET

### Installing

Installing CalcTS is easy, just start installer, sit back, relax and wait :)

## Running the tests

Tests for math library are included in repo.
There is a test for each mathematic function.

## Built With

* [C#] - Used programming language
* [Adobe Photoshop] - Used for scientific mockup
* [Visual Studio] - Used IDE for development and installer creation

## Versioning

Current version : CalcTS 1.0

## Authors

* **Marek Linner** - *Development* 
* **Radovan Babic** - *Tests and UI design* 

See also the list of [contributors](https://github.com/your/project/contributors) who participated in this project.

## License

This soft is Royalty-free, or RF, you can use it without the need to pay royalties or license fees for each use, per each copy or volume sold or some time period of use or sales.

## Acknowledgments

* Never do team project with group of irresponsible people who will leave you alone with all work to do
* We are strong, we managed to do that and ONLY GOD CAN JUDGE US!
* Peace ...

