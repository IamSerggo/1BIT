using Microsoft.VisualStudio.TestTools.UnitTesting;
using library;

namespace MathLibTest
{
	[TestClass]
	public class UnitTest1
	{
		[TestMethod]
		public void AddTest()
		{
			Assert.AreEqual(MathLibrary.Add(4, 3), 7);
			Assert.AreEqual(MathLibrary.Add(0, -4), -4);
			Assert.AreEqual(MathLibrary.Add(0, 0), 0);
			Assert.AreEqual(MathLibrary.Add(-5, -4), -9);
			Assert.AreEqual(MathLibrary.Add(5, -6), -1);
			Assert.AreEqual(MathLibrary.Add(0.2, 0.7), 0.9);
			Assert.AreEqual(MathLibrary.Add(-0.9, 0.5), -0.4);
			Assert.AreEqual(MathLibrary.Add(-1.8, -5.4), -7.2);
		}

		public void SubstractTest()
		{
			Assert.AreEqual(MathLibrary.Substract(4, 3), 1);
			Assert.AreEqual(MathLibrary.Substract(0, -4), 4);
			Assert.AreEqual(MathLibrary.Substract(0, 0), 0);
			Assert.AreEqual(MathLibrary.Substract(-5, -4), -1);
			Assert.AreEqual(MathLibrary.Substract(5, -6), 11);
			Assert.AreEqual(MathLibrary.Substract(0.2, 0.7), -0.5);
			Assert.AreEqual(MathLibrary.Substract(-0.9, 0.5), -1.4);
			Assert.AreEqual(MathLibrary.Substract(-1.8, -5.8), 4);
		}

		public void MultiplyTest()
		{
			Assert.AreEqual(MathLibrary.Multiply(4, 3), 12);
			Assert.AreEqual(MathLibrary.Multiply(0, -4), 0);
			Assert.AreEqual(MathLibrary.Multiply(0, 0), 0);
			Assert.AreEqual(MathLibrary.Multiply(-5, -4), 20);
			Assert.AreEqual(MathLibrary.Multiply(5, -6), -30);
			Assert.AreEqual(MathLibrary.Multiply(0.2, 0.7), 0.14);
			Assert.AreEqual(MathLibrary.Multiply(-0.9, 0.5), -0.45);
			Assert.AreEqual(MathLibrary.Multiply(-1.8, -5.4), 9.72);
		}

		public void DivideTest()
		{
			bool temp = false;
			Assert.AreEqual(MathLibrary.Divide(4, 2, ref temp), 2);
			Assert.AreEqual(MathLibrary.Divide(0, -4, ref temp), 0);
			Assert.AreEqual(MathLibrary.Divide(0, 0, ref temp), -1);
			Assert.AreEqual(MathLibrary.Divide(-5, -4, ref temp), 1.25);
			Assert.AreEqual(MathLibrary.Divide(5, -10, ref temp), -0.5);
			Assert.AreEqual(MathLibrary.Divide(0.2, 0.8, ref temp), 0.25);
			Assert.AreEqual(MathLibrary.Divide(-0.9, 0.5, ref temp), -1.8);
			Assert.AreEqual(MathLibrary.Divide(-1.8, -5.4, ref temp), 1.0 / 3.0);
		}

		public void FactorialTest()
		{
			Assert.AreEqual(MathLibrary.Factorial(1), 1);
			Assert.AreEqual(MathLibrary.Factorial(2), 2);
			Assert.AreEqual(MathLibrary.Factorial(0), 1);
			Assert.AreEqual(MathLibrary.Factorial(-5), -1);
			Assert.AreEqual(MathLibrary.Factorial(5), 125);
			Assert.AreEqual(MathLibrary.Factorial(0.2), -1);
			Assert.AreEqual(MathLibrary.Factorial(10), 3628800);
			Assert.AreEqual(MathLibrary.Factorial(-100), -1);
		}

		public void FindSquareRootTest()
		{
			Assert.AreEqual(MathLibrary.FindSquareRoot(1), 1);
			Assert.AreEqual(MathLibrary.FindSquareRoot(4), 2);
			Assert.AreEqual(MathLibrary.FindSquareRoot(2), 1.41421356237309);
			Assert.AreEqual(MathLibrary.FindSquareRoot(-5), -1);
			Assert.AreEqual(MathLibrary.FindSquareRoot(0), 0);
			Assert.AreEqual(MathLibrary.FindSquareRoot(16), 4);
			Assert.AreEqual(MathLibrary.FindSquareRoot(1.2), 1.09544511501033);
			Assert.AreEqual(MathLibrary.FindSquareRoot(-100), -1);
		}

		public void NthRootTest()
		{
			Assert.AreEqual(MathLibrary.NthRoot(1, 3), 1);
			Assert.AreEqual(MathLibrary.NthRoot(4, 2), 2);
			Assert.AreEqual(MathLibrary.NthRoot(8, 3), 2);
			Assert.AreEqual(MathLibrary.NthRoot(-8, 3), -2);
			Assert.AreEqual(MathLibrary.NthRoot(0, 420), 0);
			Assert.AreEqual(MathLibrary.NthRoot(16, 4), 2);
			Assert.AreEqual(MathLibrary.NthRoot(2, 3), 1.25992104989487);
		}

		public void PowerTest()
		{
			Assert.AreEqual(MathLibrary.Power(1, 3), 1);
			Assert.AreEqual(MathLibrary.Power(4, 2), 16);
			Assert.AreEqual(MathLibrary.Power(8, 3), 512);
			Assert.AreEqual(MathLibrary.Power(-8, 3), -512);
			Assert.AreEqual(MathLibrary.Power(0, 420), 1);
			Assert.AreEqual(MathLibrary.Power(2, -2), 2);
			Assert.AreEqual(MathLibrary.Power(2, 3), 1.25992104989487);
		}

		public void AbsTest()
		{
			Assert.AreEqual(MathLibrary.Abs(1), 1);
			Assert.AreEqual(MathLibrary.Abs(4), 4);
			Assert.AreEqual(MathLibrary.Abs(0), 0);
			Assert.AreEqual(MathLibrary.Abs(-8), 8);
			Assert.AreEqual(MathLibrary.Abs(-420), 420);
			Assert.AreEqual(MathLibrary.Abs(2841), 2841);
			Assert.AreEqual(MathLibrary.Abs(-2.85), 2.85);
			Assert.AreEqual(MathLibrary.Abs(0.456), 0.456);
		}
	}
}
