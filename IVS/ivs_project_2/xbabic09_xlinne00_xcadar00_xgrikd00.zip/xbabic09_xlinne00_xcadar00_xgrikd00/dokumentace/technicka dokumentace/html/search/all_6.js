var searchData=
[
  ['nthroot',['NthRoot',['../classlibrary_1_1_math_library.html#a90a9fce8b1e0d7f521e7edee36121edc',1,'library::MathLibrary']]],
  ['nthroottest',['NthRootTest',['../class_math_lib_test_1_1_unit_test1.html#ac55cc5d562cc03409e81c132facf1972',1,'MathLibTest::UnitTest1']]]
];
