var searchData=
[
  ['calculator',['calculator',['../namespacecalculator.html',1,'']]]
];
