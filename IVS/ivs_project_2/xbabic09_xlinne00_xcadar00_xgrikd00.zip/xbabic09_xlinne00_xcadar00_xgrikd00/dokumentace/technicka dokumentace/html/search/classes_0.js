var searchData=
[
  ['calc',['Calc',['../classcalculator_1_1_calc.html',1,'calculator']]]
];
