﻿using library;
using System;
using System.Windows.Forms;

namespace calculator
{

	public partial class Calc : Form
	{
		/// <summary>
		/// Initializes component Calc, nothing else.
		/// </summary>
		public Calc()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Sets property Enabled to false (for certain buttons).
		/// </summary>
		private void Form1_Load(object sender, EventArgs e)
		{
			StartState();
		}

		/// <summary>
		/// Class for keeping important variables.
		/// </summary>
		public static class Singleton
		{
			public static double firstOperand = 0;
			public static double secondOperand = 0;
			public static string output = "";
			public static bool flag = true;
			public static int lastCallOperandID = 0;
		}

		/// <summary>
		/// Method used to call library functions and calculating the result.
		/// </summary>
		/// <returns>Result of a given operation or error.</returns>
		public double CountLib()
		{
			double temp = 0;
			switch (Singleton.lastCallOperandID)
			{   
				//case for addition
				case 1:
				return MathLibrary.Add(Singleton.firstOperand, Singleton.secondOperand);

				//case for substraction
				case 2:
				return MathLibrary.Substract(Singleton.firstOperand, Singleton.secondOperand);

				//case for multiplication
				case 3:
				return MathLibrary.Multiply(Singleton.firstOperand, Singleton.secondOperand);

				//case for divison
				case 4:
				bool error = false;
				temp = MathLibrary.Divide(Singleton.firstOperand, Singleton.secondOperand, ref error);
				if (error && (temp == -1))
					Singleton.output = "Error";
				else
					return temp;
				break;

				//case for factorial
				case 5:
				temp = MathLibrary.Factorial(Singleton.firstOperand);
				if (temp == -1)
					Singleton.output = "Error";
				else
					return temp;
				break;

				//case for square root
				case 6:
				temp = MathLibrary.FindSquareRoot(Singleton.firstOperand);
				if (temp != -1)
				{
					Singleton.firstOperand = temp;
					return temp;
				}
				break;

				//case for cubic root
				case 7:
					temp = MathLibrary.NthRoot(Singleton.firstOperand, 3);
					if (temp == -1)
						Singleton.output = "Error";
				return temp;

				//case for power
				case 8:
				if (Singleton.secondOperand % 1 == 0)
					return MathLibrary.Power(Singleton.firstOperand, Convert.ToInt32(Singleton.secondOperand));
				else
					Singleton.output = "Error";
				break;

				//case for abs
				case 9:
				return MathLibrary.Abs(Singleton.firstOperand);
			}
			return -1;
		}

		/// <summary>
		/// Method used to correctly interpet data from textboxes.
		/// </summary>
		/// <param name="choice">Determines, which textbox should be used</param>
		/// <returns>Number in textbox</returns>
		public double ReadTextBox(string choice)
		{
			double result = 0;
			bool negative = false;
			if (choice == "input")
			{
				try
				{
					if (tbInput.Text[0] == '-')
						negative = true;
				}
				catch
				{
					//happens if user's input include something else than numbers
					MessageBox.Show("Wrong input. Use numbers only.");
					ResetCalc();
				}
				if (tbInput.Text.Contains(","))
				{
					string[] input = tbInput.Text.Split(',');
					result = double.Parse(input[0]) + (double.Parse(input[1]) / Math.Pow(10, input[1].Length));
				}
				else
				{
					try
					{
						result = double.Parse(tbInput.Text);
					}
					//happens if user's input include something else than numbers
					catch
					{
						MessageBox.Show("Wrong input. Use numbers only.");
						ResetCalc();
					}
				}
				return result;
			}
			else 
			{
				try
				{
					if (tbOutput.Text[0] == '-')
						negative = true;
				}
				catch { }
				if (tbOutput.Text.Contains(","))
				{
					string[] input = tbOutput.Text.Split(',');
					result = double.Parse(input[0]) + (double.Parse(input[1]) / Math.Pow(10, input[1].Length));
				}
				else
					try
					{
						result = double.Parse(tbOutput.Text);
					}
					catch { }
				negative = false;
				return result;
			}
		}

		/// <summary>
		/// Method used to set two operands to Singleton values. Works for Binary operators.
		/// </summary>
		public void SetOperands()
		{
			//Sets property Enabled for certain buttons
			FinalState();
			if (Singleton.flag)
			{
				Singleton.firstOperand = ReadTextBox("input");
				Singleton.flag = false;
				tbInput.Text = "";
			}
			else
			{
				Singleton.secondOperand = ReadTextBox("output");
				tbInput.Text = "";
			}
		}

		/// <summary>
		/// Method used to set one operand to Singleton value. Works only for Unary operators.
		/// </summary>
		public void SetOneOp()
		{
			//if this is the first use or after pressing RESET
			if (Singleton.flag)
			{
				Singleton.firstOperand = ReadTextBox("input");
				Singleton.flag = false;
			}
			else
			{
				Singleton.firstOperand = ReadTextBox("output");
			}

			double temp = CountLib();
			if (temp == -1)
			{
				Singleton.output = "Error";
				tbOutput.Text = "Error";
			}
			else
			{
				tbOutput.Text = temp.ToString();
				Singleton.firstOperand = temp;
			}
		}

		/// <summary>
		/// Disables two buttons ('=' and ','), calls the CountLib function and prints the result or error. Then sets the output as first operand
		/// </summary>
		private void btnEquals_Click(object sender, EventArgs e)
		{
			btnEquals.Enabled = false;
			btnDecimalPoint.Enabled = false;

			if (tbInput.Text != "")
			{
				Singleton.secondOperand = ReadTextBox("input");
			}

			var temp= CountLib().ToString();
			if (Singleton.output == "Error")
			{
				tbOutput.Text = "Error";
			}
			else
			{
				tbOutput.Text = temp;
				Singleton.firstOperand = ReadTextBox("output");
			}
			//after extracting the information, program clears tbInput.Text
			tbInput.Text = "";
		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnPlus_Click(object sender, EventArgs e)
		{
			SetOperands();
			Singleton.lastCallOperandID = 1;
		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnMinus_Click(object sender, EventArgs e)
		{
			SetOperands();
			Singleton.lastCallOperandID = 2;
		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnMulti_Click(object sender, EventArgs e)
		{
			SetOperands();
			Singleton.lastCallOperandID = 3;
		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnDivi_Click(object sender, EventArgs e)
		{
			SetOperands();
			Singleton.lastCallOperandID = 4;
		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnFactorial_Click(object sender, EventArgs e)
		{
			try
			{
				Singleton.lastCallOperandID = 5;
				SetOneOp();
			}
			catch
			{
				Singleton.output = "Error";
				tbOutput.Text = "Error";
			}
		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnSquareRoot_Click(object sender, EventArgs e)
		{
			try
			{
				Singleton.lastCallOperandID = 6;
				SetOneOp();
			}
			catch
			{
				Singleton.output = "Error";
				tbOutput.Text = "Error";
			}
		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnCubicRoot_Click(object sender, EventArgs e)
		{
			try
			{
				Singleton.lastCallOperandID = 7;
				SetOneOp();
			}
			catch
			{
				Singleton.output = "Error";
				tbOutput.Text = "Error";
			}
		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnAbs_Click(object sender, EventArgs e)
		{
			try
			{
				Singleton.lastCallOperandID = 9;
				SetOneOp();
			}
			catch
			{
				Singleton.output = "Error";
				tbOutput.Text = "Error";
			}

		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnToggle_Click(object sender, EventArgs e)
		{
			double temp = 0;
			if (tbInput.Text != "")
			{
				temp = ReadTextBox("input");
				temp *= -1;
				tbInput.Text = temp.ToString();
			}
		}

		/// <summary>
		/// Sets one operand and  the required operator ID
		/// </summary>
		private void btnPower_Click(object sender, EventArgs e)
		{
			try
			{
				SetOperands();
				Singleton.lastCallOperandID = 8;
			}
			catch
			{
				Singleton.output = "Error";
				tbOutput.Text = "Error";
			}
		}

		/// <summary>
		/// Sets all variables to default values
		/// </summary>
		private void btnReset_Click(object sender, EventArgs e)
		{
			ResetCalc();
		}

		/// <summary>
		/// Resets all variables to default values
		/// </summary>
		private void ResetCalc()
		{
			StartState();
			Singleton.flag = true;
			Singleton.output = "";
			Singleton.firstOperand = 0;
			Singleton.secondOperand = 0;
			tbInput.Text = "";
			tbOutput.Text = "";
		}

		/// <summary>
		/// Removes the last character in tbInput
		/// </summary>
		private void btnDel_Click(object sender, EventArgs e)
		{
			if (tbInput.Text.Length > 0)
				tbInput.Text = tbInput.Text.Remove(tbInput.Text.Length - 1, 1);
		}


		/// <summary>
		/// State of buttons on startup
		/// </summary>
		public void StartState()
		{
			btnPlus.Enabled = false;
			btnMinus.Enabled = false;
			btnMulti.Enabled = false;
			btnDivi.Enabled = false;
			btnAbs.Enabled = false;
			btnFactorial.Enabled = false;
			btnPower.Enabled = false;
			btnSquareRoot.Enabled = false;
			btnCubicRoot.Enabled = false;
			btnDel.Enabled = false;
			btnDecimalPoint.Enabled = false;
			btnEquals.Enabled = false;
			btnToggle.Enabled = false;
		}

		/// <summary>
		/// State of buttons after certain actions
		/// </summary>
		public void SecondState()
		{
			btnPlus.Enabled = true;
			btnMinus.Enabled = true;
			btnMulti.Enabled = true;
			btnDivi.Enabled = true;
			btnAbs.Enabled = true;
			btnFactorial.Enabled = true;
			btnPower.Enabled = true;
			btnSquareRoot.Enabled = true;
			btnCubicRoot.Enabled = true;
			btnDel.Enabled = true;
			btnDecimalPoint.Enabled = true;
			btnToggle.Enabled = true;
		}

		/// <summary>
		/// State of buttons after showing the result
		/// </summary>
		public void FinalState()
		{
			btnPlus.Enabled = true;
			btnMinus.Enabled = true;
			btnMulti.Enabled = true;
			btnDivi.Enabled = true;
			btnAbs.Enabled = true;
			btnFactorial.Enabled = true;
			btnPower.Enabled = true;
			btnSquareRoot.Enabled = true;
			btnCubicRoot.Enabled = true;
			btnDel.Enabled = true;
			btnDecimalPoint.Enabled = true;
			btnToggle.Enabled = true;
			btnEquals.Enabled = true;
		}


		private void btnDecimalPoint_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + ",";
			SecondState();
		}

		private void btnOne_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "1";
			SecondState();
		}
		private void btnTwo_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "2";
			SecondState();
		}
		private void btnThree_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "3";
			SecondState();
		}
		private void btnFour_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "4";
			SecondState();
		}
		private void btnFive_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "5";
			SecondState();
		}
		private void btnSix_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "6";
			SecondState();
		}
		private void btnSeven_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "7";
			SecondState();
		}
		private void btnEight_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "8";
			SecondState();
		}
		private void btnNine_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "9";
			SecondState();
		}
		private void btnZero_Click(object sender, EventArgs e)
		{
			tbInput.Text = tbInput.Text + "0";
			SecondState();
		}
	}
}
