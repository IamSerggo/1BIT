﻿using System;


namespace library
{
	public class MathLibrary
	{
		public static double Add (double a, double b)
		{
			return a + b;
		}
		
		public static double Substract (double a, double b)
		{
			return a - b;
		}

		public static double Multiply (double a, double b)
		{
			return a * b;
		}

		/// <summary>
		/// Function used to solve division operation between two given numbers
		/// </summary>
		/// <param name="a">First operand</param>
		/// <param name="b">Second operand - must not be 0</param>
		/// <param name="error">Variable which keeps check, whether the function worked correctly</param>
		/// <returns>Result after dividing a/b</returns>
		public static double Divide (double a, double b, ref bool error)
		{
			if (b==0)
			{
				error = true;
				return -1;
			}
			return a / b;
		}

		/// <summary>
		/// Function used to solve factorial of a given number
		/// </summary>
		/// <param name="a">Whole, positive number</param>
		/// <returns>Factorial of a</returns>
		public static double Factorial (double a)
		{
			if ((a < 0)||(a % 1 != 0))
			{
				return -1;
			}
			double sum = 1;
			for (double i=a; i > 0; i--)
			{
				sum *= i;
			}
			return sum;
		}

		/// <summary>
		/// Method used to calculate square root of a number
		/// </summary>
		/// <param name="a">Given number</param>
		/// <returns>Square root of a</returns>
		public static double FindSquareRoot (double a)
		{
			if (a < 0)
			{
				return -1;
			}
			double precision = 10e-8;
			double prev = 0.0;
			double mid = a;
			while (Math.Abs(mid - prev) > precision)
			{
				prev = mid;
				mid = (mid + (a / mid)) / 2.0;
			}
			return mid;
		}


		/// <summary>
		/// Function used to solve Nth root
		/// </summary>
		/// <param name="A"></param>
		/// <param name="n"></param>
		/// <returns>Nth root of A</returns>
		public static double NthRoot(double A, int n)
		{
			double p = 0.0000001;
			double _n = (double)n;
			double[] x = new double[2];
			x[0] = A;
			x[1] = A / _n;
			while (Math.Abs(x[0] - x[1]) > p)
			{
				x[1] = x[0];
				x[0] = (1 / _n) * (((_n - 1) * x[1]) + (A / Math.Pow(x[1], _n - 1)));

			}
			return x[0];
		}

		/// <summary>
		/// Function used to solve Power function with natural-number-only exponents
		/// </summary>
		/// <param name="a">Base</param>
		/// <param name="b">Degree</param>
		/// <returns>a powered to b</returns>
		public static double Power(double a, int b)
		{
			double y = 1;
			while (true)
			{
				if ((b & 1) != 0)
					y = a * y;
				b = b >> 1;
				if (b == 0)
					return y;
				a *= a;
			}
		}

		/// <summary>
		/// Method which returns absolute value of a give param
		/// </summary>
		/// <param name="a">Input</param>
		/// <returns>Absolute value of a</returns>
		public static double Abs (double a)
		{
			if (a < 0)
				return a * -1;
			else
				return a;
		}
	}
}
