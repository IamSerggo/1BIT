﻿namespace calculator
{
	partial class Calc
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnPlus = new System.Windows.Forms.Button();
			this.btnMinus = new System.Windows.Forms.Button();
			this.btnMulti = new System.Windows.Forms.Button();
			this.btnDivi = new System.Windows.Forms.Button();
			this.btnFactorial = new System.Windows.Forms.Button();
			this.btnOne = new System.Windows.Forms.Button();
			this.btnTwo = new System.Windows.Forms.Button();
			this.btnThree = new System.Windows.Forms.Button();
			this.btnSquareRoot = new System.Windows.Forms.Button();
			this.btnFour = new System.Windows.Forms.Button();
			this.btnFive = new System.Windows.Forms.Button();
			this.btnSix = new System.Windows.Forms.Button();
			this.btnPower = new System.Windows.Forms.Button();
			this.btnSeven = new System.Windows.Forms.Button();
			this.btnEight = new System.Windows.Forms.Button();
			this.btnNine = new System.Windows.Forms.Button();
			this.btnZero = new System.Windows.Forms.Button();
			this.btnDecimalPoint = new System.Windows.Forms.Button();
			this.btnEquals = new System.Windows.Forms.Button();
			this.tbInput = new System.Windows.Forms.TextBox();
			this.tbOutput = new System.Windows.Forms.TextBox();
			this.btnCubicRoot = new System.Windows.Forms.Button();
			this.btnToggle = new System.Windows.Forms.Button();
			this.btnAbs = new System.Windows.Forms.Button();
			this.btnDel = new System.Windows.Forms.Button();
			this.btnReset = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnPlus
			// 
			this.btnPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnPlus.Location = new System.Drawing.Point(2, 136);
			this.btnPlus.Name = "btnPlus";
			this.btnPlus.Size = new System.Drawing.Size(130, 100);
			this.btnPlus.TabIndex = 0;
			this.btnPlus.Text = "+";
			this.btnPlus.UseVisualStyleBackColor = true;
			this.btnPlus.Click += new System.EventHandler(this.btnPlus_Click);
			// 
			// btnMinus
			// 
			this.btnMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnMinus.Location = new System.Drawing.Point(138, 136);
			this.btnMinus.Name = "btnMinus";
			this.btnMinus.Size = new System.Drawing.Size(130, 100);
			this.btnMinus.TabIndex = 1;
			this.btnMinus.Text = "-";
			this.btnMinus.UseVisualStyleBackColor = true;
			this.btnMinus.Click += new System.EventHandler(this.btnMinus_Click);
			// 
			// btnMulti
			// 
			this.btnMulti.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnMulti.Location = new System.Drawing.Point(274, 136);
			this.btnMulti.Name = "btnMulti";
			this.btnMulti.Size = new System.Drawing.Size(130, 100);
			this.btnMulti.TabIndex = 2;
			this.btnMulti.Text = "*";
			this.btnMulti.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.btnMulti.UseVisualStyleBackColor = true;
			this.btnMulti.Click += new System.EventHandler(this.btnMulti_Click);
			// 
			// btnDivi
			// 
			this.btnDivi.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnDivi.Location = new System.Drawing.Point(410, 136);
			this.btnDivi.Name = "btnDivi";
			this.btnDivi.Size = new System.Drawing.Size(130, 100);
			this.btnDivi.TabIndex = 3;
			this.btnDivi.Text = "/";
			this.btnDivi.UseVisualStyleBackColor = true;
			this.btnDivi.Click += new System.EventHandler(this.btnDivi_Click);
			// 
			// btnFactorial
			// 
			this.btnFactorial.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnFactorial.Location = new System.Drawing.Point(2, 246);
			this.btnFactorial.Name = "btnFactorial";
			this.btnFactorial.Size = new System.Drawing.Size(130, 100);
			this.btnFactorial.TabIndex = 4;
			this.btnFactorial.Text = "x!";
			this.btnFactorial.UseVisualStyleBackColor = true;
			this.btnFactorial.Click += new System.EventHandler(this.btnFactorial_Click);
			// 
			// btnOne
			// 
			this.btnOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnOne.Location = new System.Drawing.Point(138, 246);
			this.btnOne.Name = "btnOne";
			this.btnOne.Size = new System.Drawing.Size(130, 100);
			this.btnOne.TabIndex = 5;
			this.btnOne.Text = "1";
			this.btnOne.UseVisualStyleBackColor = true;
			this.btnOne.Click += new System.EventHandler(this.btnOne_Click);
			// 
			// btnTwo
			// 
			this.btnTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnTwo.Location = new System.Drawing.Point(274, 246);
			this.btnTwo.Name = "btnTwo";
			this.btnTwo.Size = new System.Drawing.Size(130, 100);
			this.btnTwo.TabIndex = 6;
			this.btnTwo.Text = "2";
			this.btnTwo.UseVisualStyleBackColor = true;
			this.btnTwo.Click += new System.EventHandler(this.btnTwo_Click);
			// 
			// btnThree
			// 
			this.btnThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnThree.Location = new System.Drawing.Point(410, 246);
			this.btnThree.Name = "btnThree";
			this.btnThree.Size = new System.Drawing.Size(130, 100);
			this.btnThree.TabIndex = 7;
			this.btnThree.Text = "3";
			this.btnThree.UseVisualStyleBackColor = true;
			this.btnThree.Click += new System.EventHandler(this.btnThree_Click);
			// 
			// btnSquareRoot
			// 
			this.btnSquareRoot.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnSquareRoot.Location = new System.Drawing.Point(2, 356);
			this.btnSquareRoot.Name = "btnSquareRoot";
			this.btnSquareRoot.Size = new System.Drawing.Size(130, 100);
			this.btnSquareRoot.TabIndex = 8;
			this.btnSquareRoot.Text = "√x";
			this.btnSquareRoot.UseVisualStyleBackColor = true;
			this.btnSquareRoot.Click += new System.EventHandler(this.btnSquareRoot_Click);
			// 
			// btnFour
			// 
			this.btnFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnFour.Location = new System.Drawing.Point(138, 356);
			this.btnFour.Name = "btnFour";
			this.btnFour.Size = new System.Drawing.Size(130, 100);
			this.btnFour.TabIndex = 9;
			this.btnFour.Text = "4";
			this.btnFour.UseVisualStyleBackColor = true;
			this.btnFour.Click += new System.EventHandler(this.btnFour_Click);
			// 
			// btnFive
			// 
			this.btnFive.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnFive.Location = new System.Drawing.Point(274, 356);
			this.btnFive.Name = "btnFive";
			this.btnFive.Size = new System.Drawing.Size(130, 100);
			this.btnFive.TabIndex = 10;
			this.btnFive.Text = "5";
			this.btnFive.UseVisualStyleBackColor = true;
			this.btnFive.Click += new System.EventHandler(this.btnFive_Click);
			// 
			// btnSix
			// 
			this.btnSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnSix.Location = new System.Drawing.Point(410, 356);
			this.btnSix.Name = "btnSix";
			this.btnSix.Size = new System.Drawing.Size(130, 100);
			this.btnSix.TabIndex = 11;
			this.btnSix.Text = "6";
			this.btnSix.UseVisualStyleBackColor = true;
			this.btnSix.Click += new System.EventHandler(this.btnSix_Click);
			// 
			// btnPower
			// 
			this.btnPower.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnPower.Location = new System.Drawing.Point(2, 576);
			this.btnPower.Name = "btnPower";
			this.btnPower.Size = new System.Drawing.Size(130, 100);
			this.btnPower.TabIndex = 12;
			this.btnPower.Text = "x^n";
			this.btnPower.UseVisualStyleBackColor = true;
			this.btnPower.Click += new System.EventHandler(this.btnPower_Click);
			// 
			// btnSeven
			// 
			this.btnSeven.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnSeven.Location = new System.Drawing.Point(138, 466);
			this.btnSeven.Name = "btnSeven";
			this.btnSeven.Size = new System.Drawing.Size(130, 100);
			this.btnSeven.TabIndex = 13;
			this.btnSeven.Text = "7";
			this.btnSeven.UseVisualStyleBackColor = true;
			this.btnSeven.Click += new System.EventHandler(this.btnSeven_Click);
			// 
			// btnEight
			// 
			this.btnEight.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnEight.Location = new System.Drawing.Point(274, 466);
			this.btnEight.Name = "btnEight";
			this.btnEight.Size = new System.Drawing.Size(130, 100);
			this.btnEight.TabIndex = 14;
			this.btnEight.Text = "8";
			this.btnEight.UseVisualStyleBackColor = true;
			this.btnEight.Click += new System.EventHandler(this.btnEight_Click);
			// 
			// btnNine
			// 
			this.btnNine.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnNine.Location = new System.Drawing.Point(410, 466);
			this.btnNine.Name = "btnNine";
			this.btnNine.Size = new System.Drawing.Size(130, 100);
			this.btnNine.TabIndex = 15;
			this.btnNine.Text = "9";
			this.btnNine.UseVisualStyleBackColor = true;
			this.btnNine.Click += new System.EventHandler(this.btnNine_Click);
			// 
			// btnZero
			// 
			this.btnZero.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnZero.Location = new System.Drawing.Point(274, 576);
			this.btnZero.Name = "btnZero";
			this.btnZero.Size = new System.Drawing.Size(130, 100);
			this.btnZero.TabIndex = 17;
			this.btnZero.Text = "0";
			this.btnZero.UseVisualStyleBackColor = true;
			this.btnZero.Click += new System.EventHandler(this.btnZero_Click);
			// 
			// btnDecimalPoint
			// 
			this.btnDecimalPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnDecimalPoint.Location = new System.Drawing.Point(138, 576);
			this.btnDecimalPoint.Name = "btnDecimalPoint";
			this.btnDecimalPoint.Size = new System.Drawing.Size(130, 100);
			this.btnDecimalPoint.TabIndex = 18;
			this.btnDecimalPoint.Text = ",";
			this.btnDecimalPoint.UseVisualStyleBackColor = true;
			this.btnDecimalPoint.Click += new System.EventHandler(this.btnDecimalPoint_Click);
			// 
			// btnEquals
			// 
			this.btnEquals.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnEquals.Location = new System.Drawing.Point(410, 576);
			this.btnEquals.Name = "btnEquals";
			this.btnEquals.Size = new System.Drawing.Size(264, 100);
			this.btnEquals.TabIndex = 19;
			this.btnEquals.Text = "=";
			this.btnEquals.UseVisualStyleBackColor = true;
			this.btnEquals.Click += new System.EventHandler(this.btnEquals_Click);
			// 
			// tbInput
			// 
			this.tbInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.tbInput.Location = new System.Drawing.Point(2, 1);
			this.tbInput.Name = "tbInput";
			this.tbInput.Size = new System.Drawing.Size(672, 45);
			this.tbInput.TabIndex = 20;
			this.tbInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// tbOutput
			// 
			this.tbOutput.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.tbOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.tbOutput.Location = new System.Drawing.Point(2, 66);
			this.tbOutput.Name = "tbOutput";
			this.tbOutput.ReadOnly = true;
			this.tbOutput.Size = new System.Drawing.Size(672, 57);
			this.tbOutput.TabIndex = 21;
			this.tbOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// btnCubicRoot
			// 
			this.btnCubicRoot.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnCubicRoot.Location = new System.Drawing.Point(2, 466);
			this.btnCubicRoot.Name = "btnCubicRoot";
			this.btnCubicRoot.Size = new System.Drawing.Size(130, 100);
			this.btnCubicRoot.TabIndex = 22;
			this.btnCubicRoot.Text = "3√x";
			this.btnCubicRoot.UseVisualStyleBackColor = true;
			this.btnCubicRoot.Click += new System.EventHandler(this.btnCubicRoot_Click);
			// 
			// btnToggle
			// 
			this.btnToggle.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnToggle.Location = new System.Drawing.Point(546, 466);
			this.btnToggle.Name = "btnToggle";
			this.btnToggle.Size = new System.Drawing.Size(130, 100);
			this.btnToggle.TabIndex = 26;
			this.btnToggle.Text = "+/-";
			this.btnToggle.UseVisualStyleBackColor = true;
			this.btnToggle.Click += new System.EventHandler(this.btnToggle_Click);
			// 
			// btnAbs
			// 
			this.btnAbs.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnAbs.Location = new System.Drawing.Point(546, 356);
			this.btnAbs.Name = "btnAbs";
			this.btnAbs.Size = new System.Drawing.Size(130, 100);
			this.btnAbs.TabIndex = 25;
			this.btnAbs.Text = "ABS";
			this.btnAbs.UseVisualStyleBackColor = true;
			this.btnAbs.Click += new System.EventHandler(this.btnAbs_Click);
			// 
			// btnDel
			// 
			this.btnDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnDel.Location = new System.Drawing.Point(546, 246);
			this.btnDel.Name = "btnDel";
			this.btnDel.Size = new System.Drawing.Size(130, 100);
			this.btnDel.TabIndex = 24;
			this.btnDel.Text = "DEL";
			this.btnDel.UseVisualStyleBackColor = true;
			this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
			// 
			// btnReset
			// 
			this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.btnReset.Location = new System.Drawing.Point(546, 136);
			this.btnReset.Name = "btnReset";
			this.btnReset.Size = new System.Drawing.Size(130, 100);
			this.btnReset.TabIndex = 23;
			this.btnReset.Text = "RESET";
			this.btnReset.UseVisualStyleBackColor = true;
			this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
			// 
			// Calc
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(673, 675);
			this.Controls.Add(this.btnToggle);
			this.Controls.Add(this.btnAbs);
			this.Controls.Add(this.btnDel);
			this.Controls.Add(this.btnReset);
			this.Controls.Add(this.btnCubicRoot);
			this.Controls.Add(this.tbOutput);
			this.Controls.Add(this.tbInput);
			this.Controls.Add(this.btnEquals);
			this.Controls.Add(this.btnDecimalPoint);
			this.Controls.Add(this.btnZero);
			this.Controls.Add(this.btnNine);
			this.Controls.Add(this.btnEight);
			this.Controls.Add(this.btnSeven);
			this.Controls.Add(this.btnPower);
			this.Controls.Add(this.btnSix);
			this.Controls.Add(this.btnFive);
			this.Controls.Add(this.btnFour);
			this.Controls.Add(this.btnSquareRoot);
			this.Controls.Add(this.btnThree);
			this.Controls.Add(this.btnTwo);
			this.Controls.Add(this.btnOne);
			this.Controls.Add(this.btnFactorial);
			this.Controls.Add(this.btnDivi);
			this.Controls.Add(this.btnMulti);
			this.Controls.Add(this.btnMinus);
			this.Controls.Add(this.btnPlus);
			this.Name = "Calc";
			this.Text = "Calculator";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnPlus;
		private System.Windows.Forms.Button btnMinus;
		private System.Windows.Forms.Button btnMulti;
		private System.Windows.Forms.Button btnDivi;
		private System.Windows.Forms.Button btnFactorial;
		private System.Windows.Forms.Button btnOne;
		private System.Windows.Forms.Button btnTwo;
		private System.Windows.Forms.Button btnThree;
		private System.Windows.Forms.Button btnSquareRoot;
		private System.Windows.Forms.Button btnFour;
		private System.Windows.Forms.Button btnFive;
		private System.Windows.Forms.Button btnSix;
		private System.Windows.Forms.Button btnPower;
		private System.Windows.Forms.Button btnSeven;
		private System.Windows.Forms.Button btnEight;
		private System.Windows.Forms.Button btnNine;
		private System.Windows.Forms.Button btnZero;
		private System.Windows.Forms.Button btnDecimalPoint;
		private System.Windows.Forms.Button btnEquals;
		public System.Windows.Forms.TextBox tbInput;
		private System.Windows.Forms.Button btnCubicRoot;
		private System.Windows.Forms.Button btnToggle;
		private System.Windows.Forms.Button btnAbs;
		private System.Windows.Forms.Button btnDel;
		private System.Windows.Forms.Button btnReset;
		public System.Windows.Forms.TextBox tbOutput;
	}
}

