﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using library;
using System;

namespace MathLibTest
{
	[TestClass]
	public class UnitTest1
	{


		private readonly MathLibrary _MathLibrary = new MathLibrary();
		[TestMethod]
		public void AddTest()
		{
			Assert.AreEqual(library.MathLibrary.Add(4, 3), 7);
			Assert.AreEqual(library.MathLibrary.Add(0, -4), -4);
			Assert.AreEqual(library.MathLibrary.Add(0, 0), 0);
			Assert.AreEqual(library.MathLibrary.Add(-5, -4), -9);
			Assert.AreEqual(library.MathLibrary.Add(5, -6), -1);
			Assert.AreEqual(library.MathLibrary.Add(0.2, 0.6), 0.8);
			Assert.AreEqual(library.MathLibrary.Add(-0.9, 0.5), -0.4);
			Assert.AreEqual(library.MathLibrary.Add(-1.8, -5.4), -7.2);
		}

		[TestMethod]
		public void SubstractTest()
		{
			Assert.AreEqual(library.MathLibrary.Substract(4, 3), 1);
			Assert.AreEqual(library.MathLibrary.Substract(0, -4), 4);
			Assert.AreEqual(library.MathLibrary.Substract(0, 0), 0);
			Assert.AreEqual(library.MathLibrary.Substract(-5, -4), -1);
			Assert.AreEqual(library.MathLibrary.Substract(5, -6), 11);
			Assert.AreEqual(library.MathLibrary.Substract(0, 10.5), -10.5);
			Assert.AreEqual(library.MathLibrary.Substract(-0.9, 0.5), -1.4);
			Assert.AreEqual(library.MathLibrary.Substract(-1.8, -5.8), 4);
		}

		[TestMethod]
		public void MultiplyTest()
		{
			Assert.AreEqual(library.MathLibrary.Multiply(4, 3), 12);
			Assert.AreEqual(library.MathLibrary.Multiply(0, -4), 0);
			Assert.AreEqual(library.MathLibrary.Multiply(0, 0), 0);
			Assert.AreEqual(library.MathLibrary.Multiply(-5, -4), 20);
			Assert.AreEqual(library.MathLibrary.Multiply(5, -6), -30);
			Assert.AreEqual(library.MathLibrary.Multiply(0.2, 0.6), 0.12);
			Assert.AreEqual(library.MathLibrary.Multiply(-0.9, 0.5), -0.45);
			Assert.AreEqual(library.MathLibrary.Multiply(-1.8, -5.4), 9.72);
		}

		[TestMethod]
		public void DivideTest()
		{
			bool temp = false;
			Assert.AreEqual(library.MathLibrary.Divide(4, 2, ref temp), 2);
			Assert.AreEqual(library.MathLibrary.Divide(0, -4, ref temp), 0);
			Assert.AreEqual(library.MathLibrary.Divide(0, 0, ref temp), -1);
			Assert.AreEqual(library.MathLibrary.Divide(-5, -4, ref temp), 1.25);
			Assert.AreEqual(library.MathLibrary.Divide(5, -10, ref temp), -0.5);
			Assert.AreEqual(library.MathLibrary.Divide(0.2, 0.8, ref temp), 0.25);
			Assert.AreEqual(library.MathLibrary.Divide(-0.9, 0.5, ref temp), -1.8);
			Assert.AreEqual(library.MathLibrary.Divide(-1.8, -5.4, ref temp), 1.0 / 3.0);
		}

		[TestMethod]
		public void FactorialTest()
		{
			Assert.AreEqual(library.MathLibrary.Factorial(1), 1);
			Assert.AreEqual(library.MathLibrary.Factorial(2), 2);
			Assert.AreEqual(library.MathLibrary.Factorial(0), 1);
			Assert.AreEqual(library.MathLibrary.Factorial(-5), -1);
			Assert.AreEqual(library.MathLibrary.Factorial(5), 120);
			Assert.AreEqual(library.MathLibrary.Factorial(0.2), -1);
			Assert.AreEqual(library.MathLibrary.Factorial(6), 720);
			Assert.AreEqual(library.MathLibrary.Factorial(-100), -1);
			Assert.AreEqual(library.MathLibrary.Factorial(-1.5), -1);
		}

		[TestMethod]
		public void FindSquareRootTest()
		{
			Assert.AreEqual(library.MathLibrary.FindSquareRoot(1), 1);
			Assert.AreEqual(library.MathLibrary.FindSquareRoot(9), 3);
			Assert.AreEqual(library.MathLibrary.FindSquareRoot(-5), -1);
			Assert.AreEqual(library.MathLibrary.FindSquareRoot(0), 0);
			Assert.AreEqual(library.MathLibrary.FindSquareRoot(16), 4);
			Assert.AreEqual(library.MathLibrary.FindSquareRoot(-100), -1);
		}

		[TestMethod]
		public void NthRootTest()
		{
			Assert.AreEqual(library.MathLibrary.NthRoot(1, 3), 1);
			Assert.AreEqual(library.MathLibrary.NthRoot(216, 3), 6);
			Assert.AreEqual(library.MathLibrary.NthRoot(1728, 3), 12);
			Assert.AreEqual(library.MathLibrary.NthRoot(-8, 3), -2);
			Assert.AreEqual(library.MathLibrary.NthRoot(0, 420), 0);
			Assert.AreEqual(library.MathLibrary.NthRoot(16, 4), 2);
		}

		[TestMethod]
		public void PowerTest()
		{
			Assert.AreEqual(library.MathLibrary.Power(1, 3), 1);
			Assert.AreEqual(library.MathLibrary.Power(4, 2), 16);
			Assert.AreEqual(library.MathLibrary.Power(8, 3), 512);
			Assert.AreEqual(library.MathLibrary.Power(-8, 3), -512);
			Assert.AreEqual(library.MathLibrary.Power(2, -2), 1/2);
		}

		[TestMethod]
		public void AbsTest()
		{
			Assert.AreEqual(library.MathLibrary.Abs(1), 1);
			Assert.AreEqual(library.MathLibrary.Abs(4), 4);
			Assert.AreEqual(library.MathLibrary.Abs(0), 0);
			Assert.AreEqual(library.MathLibrary.Abs(-8), 8);
			Assert.AreEqual(library.MathLibrary.Abs(-420), 420);
			Assert.AreEqual(library.MathLibrary.Abs(2841), 2841);
			Assert.AreEqual(library.MathLibrary.Abs(-2.85), 2.85);
			Assert.AreEqual(library.MathLibrary.Abs(0.456), 0.456);
		}
	}
}
