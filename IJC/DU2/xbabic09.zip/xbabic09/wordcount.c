/**
 *	@file	wordcount.c
 *	@author	Radovan Babic, xbabic09
 *	@date	24.4.2018
 *	@brief	wordcount
 */

 #include "htab.h"
